<?php
require_once "../config/auth.php";
require_once "../config/koneksi.php";

$sql = "SELECT id, foto, nim, nama, program_studi, email
        FROM mahasiswa
        ORDER BY id DESC";

$result = $conn->query($sql);
if (!$result) {
    die("Query error: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Mahasiswa</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header>
    <h1>Data Mahasiswa</h1>
    <p>Web Programming 1</p>
</header>

<nav>
    <a href="dashboard.php">Dashboard</a>
    <a href="index.php">Biodata</a>
    <a href="layout.php">Layout Lab</a>
    <a href="data_mahasiswa.php" class="active">Data Mahasiswa</a>
    <a href="form_mahasiswa.php">Tambah Mahasiswa</a>
    <a href="../crud/index.php">CRUD Mahasiswa</a>
    <a href="../proses/logout.php">Logout</a>
</nav>

<main>
    <section>
        <h2>Daftar Mahasiswa</h2>

        <?php if (isset($_GET["status"]) && $_GET["status"] === "sukses"): ?>
            <p class="alert-sukses">Data berhasil ditambahkan.</p>
        <?php endif; ?>

        <table class="data-table">
            <thead>
                <tr>
                    <th style="width: 50px;">No</th>
                    <th style="width: 70px; text-align: center;">Foto</th>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>Program Studi</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody>

            <?php if ($result->num_rows === 0): ?>
                <tr>
                    <td colspan="6" style="text-align: center; color: #666; padding: 20px;">
                        Belum ada data mahasiswa. Silakan tambah data melalui menu <a href="form_mahasiswa.php">Tambah Mahasiswa</a>.
                    </td>
                </tr>
            <?php else: ?>
                <?php $no = 1; ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <?php
                        $fotoFile = $row["foto"] ?? "";
                        $fotoSrc = "../assets/images/default-avatar.svg";
                        if (!empty($fotoFile)) {
                            if (file_exists(__DIR__ . "/../uploads/images/" . $fotoFile)) {
                                $fotoSrc = "../uploads/images/" . htmlspecialchars($fotoFile);
                            } elseif (file_exists(__DIR__ . "/../assets/images/" . $fotoFile)) {
                                $fotoSrc = "../assets/images/" . htmlspecialchars($fotoFile);
                            }
                        }
                    ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td style="text-align: center;">
                            <img src="<?= $fotoSrc ?>" alt="Foto <?= htmlspecialchars($row["nama"]) ?>" class="table-photo">
                        </td>
                        <td><?= htmlspecialchars($row["nim"]); ?></td>
                        <td><?= htmlspecialchars($row["nama"]); ?></td>
                        <td><?= htmlspecialchars($row["program_studi"]); ?></td>
                        <td><?= htmlspecialchars($row["email"]); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php endif; ?>

            </tbody>
        </table>
    </section>
</main>

<footer>
    <p>Web Programming 1</p>
</footer>

</body>
</html>
<?php
$conn->close();
?>
