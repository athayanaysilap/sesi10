# Web Programming 1 - Sesi 9 (CRUD Mahasiswa & Foldering)

Proyek integrasi struktur folder modular (foldering) dan modul CRUD (Create, Read, Update, Delete) Mahasiswa lengkap dengan autentikasi session dan antarmuka interaktif.

## 📁 Struktur Folder Project

```text
afteruts/ (sesi 9)
├── assets/
│   ├── css/
│   │   └── style.css
│   ├── images/
│   │   ├── foto.jpg
│   │   └── profile.jpg
│   └── js/
│       └── crud.js (Pencarian real-time & konfirmasi hapus)
├── config/
│   ├── auth.php (Session guard)
│   └── koneksi.php (Koneksi database MySQLi)
├── database/
│   └── database.sql (Backup tabel mahasiswa & users)
├── pages/
│   ├── dashboard.php
│   ├── data_mahasiswa.php
│   ├── form_mahasiswa.php (Modul 4B)
│   ├── index.php (Biodata)
│   ├── layout.php
│   └── login.php
├── crud/
│   ├── index.php (Tabel CRUD lengkap + search + action)
│   ├── tambah.php (Form tambah data mahasiswa)
│   └── edit.php (Form edit data mahasiswa)
├── proses/
│   ├── buat_user.php
│   ├── logout.php
│   ├── proses_login.php
│   ├── proses_tambah.php (Proses lama modul 4B)
│   ├── proses_crud_tambah.php (Proses tambah CRUD + upload media)
│   ├── proses_update.php (Proses update CRUD + update media)
│   └── proses_hapus.php (Proses delete CRUD + delete file media)
├── uploads/
│   ├── images/ (Direktori penyimpanan foto mahasiswa)
│   └── audio/ (Direktori penyimpanan audio mahasiswa)
├── .htaccess
├── index.php (Redirect otomatis)
└── README.md
```

## 🚀 Fitur Utama
1. **Foldering & Relative Path Modular**: Pemisahan berkas ke dalam direktori `assets/`, `config/`, `database/`, `pages/`, `crud/`, `proses/`, dan `uploads/`.
2. **Navigasi Terintegrasi**: Navbar di setiap halaman `pages/` dan `crud/` saling terhubung dengan relative path yang tepat.
3. **Fitur CRUD Mahasiswa & Media**:
   - **Tampilan Foto Mahasiswa**: Thumbnail foto bulat-kotak (rounded avatar) di tabel CRUD dan Data Mahasiswa sesuai standar antarmuka CRUD Media.
   - **Upload & Preview Foto**: Form tambah dan edit dilengkapi input file foto dengan live preview instan via JavaScript.
   - **Dukungan Audio**: Kolom pemutar audio opsional dengan tag `<audio controls>`.
   - **Read**: Menampilkan seluruh data mahasiswa dengan sorting ID terbaru (`ORDER BY id DESC`).
   - **Create**: Form penambahan data mahasiswa baru beserta upload foto/audio.
   - **Update**: Edit data mahasiswa dengan auto-fill dan preview foto saat ini.
   - **Delete**: Hapus data aman menggunakan method POST, prepared statement, dan penghapusan file foto lama di server secara otomatis.
4. **Pencarian Real-Time (`assets/js/crud.js`)**: Filter data mahasiswa secara langsung berdasarkan NIM, nama, program studi, atau email tanpa reload halaman.

## ⚙️ Persyaratan & Panduan Menjalankan di Laragon

### 1. Persyaratan Lingkungan
- Web Server: **Apache** (tersedia di Laragon)
- Database: **MySQL 8.x** (tersedia di Laragon)
- PHP: **PHP 8.x** (tersedia di Laragon)
- Database: `web_programming_1`

### 2. Cara Menjalankan Project (Menggunakan Apache Laragon)
> **Penting**: Tidak perlu menjalankan perintah PHP built-in server (`php -S localhost:8000`) atau path PHP CLI manual. Laragon sudah mengelola Apache dan MySQL secara otomatis.

1. Buka aplikasi **Laragon**.
2. Klik tombol **"Start All"** pada Laragon untuk mengaktifkan Apache dan MySQL.
3. Pastikan database `web_programming_1` sudah ada. Jika belum:
   - Buka menu **Database** (HeidiSQL) atau **phpMyAdmin** dari Laragon.
   - Buat database `web_programming_1` atau impor file `database/database.sql`.
4. Buka browser (Chrome / Edge / Firefox) dan akses:
   ```text
   http://localhost/sesi 9/
   ```
   (atau `http://localhost/sesi%209/`)
5. Login menggunakan akun default:
   - **Username**: `admin`
   - **Password**: `admin123`
