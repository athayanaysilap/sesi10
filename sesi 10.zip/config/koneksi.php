<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "web_programming_1";

// Nonaktifkan uncaught exception mysqli agar pesan error ditangani secara ramah
mysqli_report(MYSQLI_REPORT_OFF);

$conn = @new mysqli(
    $host,
    $user,
    $password,
    $database
);

if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error . "<br><br><small>Petunjuk: Pastikan Apache & MySQL di Laragon sudah aktif (klik tombol <strong>Start All</strong> di aplikasi Laragon) dan database <strong>" . htmlspecialchars($database) . "</strong> sudah diimpor.</small>");
}

$conn->set_charset("utf8mb4");

// Pastikan kolom foto & audio otomatis tersedia pada tabel mahasiswa jika belum ada
$checkTable = $conn->query("SHOW TABLES LIKE 'mahasiswa'");
if ($checkTable && $checkTable->num_rows > 0) {
    $checkFoto = $conn->query("SHOW COLUMNS FROM `mahasiswa` LIKE 'foto'");
    if ($checkFoto && $checkFoto->num_rows === 0) {
        $conn->query("ALTER TABLE `mahasiswa` ADD COLUMN `foto` VARCHAR(255) DEFAULT 'default-avatar.svg' AFTER `id`");
    }
    $checkAudio = $conn->query("SHOW COLUMNS FROM `mahasiswa` LIKE 'audio'");
    if ($checkAudio && $checkAudio->num_rows === 0) {
        $conn->query("ALTER TABLE `mahasiswa` ADD COLUMN `audio` VARCHAR(255) NULL AFTER `email`");
    }

    // Perbarui foto Athaya & Ardianti ke file foto terbaru
    $conn->query("UPDATE `mahasiswa` SET `foto` = 'athaya_ardianti.jpg' WHERE `nama` LIKE '%Athaya%' OR `nama` LIKE '%Ardianti%'");

    // Jika data Ardianti belum ada di tabel, tambahkan otomatis
    $checkArdianti = $conn->query("SELECT id FROM `mahasiswa` WHERE `nama` LIKE '%Ardianti%' LIMIT 1");
    if ($checkArdianti && $checkArdianti->num_rows === 0) {
        $conn->query("INSERT INTO `mahasiswa` (`foto`, `nim`, `nama`, `program_studi`, `email`) VALUES ('athaya_ardianti.jpg', '4112755201250063', 'Ardianti', 'Informatika', 'ardianti@gmail.com')");
    }
}
?>
