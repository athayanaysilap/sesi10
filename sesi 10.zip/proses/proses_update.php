<?php
require_once "../config/auth.php";
require_once "../config/koneksi.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../crud/index.php");
    exit;
}

$id = (int) ($_POST["id"] ?? 0);
$nim = trim($_POST["nim"] ?? "");
$nama = trim($_POST["nama"] ?? "");
$program_studi = trim($_POST["program_studi"] ?? "");
$email = trim($_POST["email"] ?? "");

if ($id <= 0 || $nim === "" || $nama === "" || $program_studi === "" || $email === "") {
    die("Data update tidak valid. <a href='../crud/index.php'>Kembali ke CRUD</a>");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Format email tidak valid. <a href='../crud/edit.php?id=" . $id . "'>Kembali ke Form Edit</a>");
}

// Ambil data foto & audio lama
$qOld = $conn->prepare("SELECT foto, audio FROM mahasiswa WHERE id = ? LIMIT 1");
$qOld->bind_param("i", $id);
$qOld->execute();
$oldData = $qOld->get_result()->fetch_assoc();
$qOld->close();

$fotoName = $oldData["foto"] ?? "default-avatar.svg";
$audioName = $oldData["audio"] ?? null;

// Proses Update Foto Baru
if (isset($_FILES["foto"]) && $_FILES["foto"]["error"] === UPLOAD_ERR_OK) {
    $fileTmp = $_FILES["foto"]["tmp_name"];
    $fileSize = $_FILES["foto"]["size"];
    $fileExt = strtolower(pathinfo($_FILES["foto"]["name"], PATHINFO_EXTENSION));

    if ($fileSize > 2 * 1024 * 1024) {
        die("Ukuran foto maksimal 2MB. <a href='../crud/edit.php?id=" . $id . "'>Kembali</a>");
    }

    if (!in_array($fileExt, ["jpg", "jpeg", "png", "webp", "gif"])) {
        die("Format foto tidak didukung (gunakan JPG, PNG, WEBP). <a href='../crud/edit.php?id=" . $id . "'>Kembali</a>");
    }

    $uploadDir = __DIR__ . "/../uploads/images/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $newFoto = "foto_" . time() . "_" . bin2hex(random_bytes(4)) . "." . $fileExt;
    if (move_uploaded_file($fileTmp, $uploadDir . $newFoto)) {
        // Hapus foto lama jika bukan foto default
        if (!empty($fotoName) && !in_array($fotoName, ["default-avatar.svg", "foto.jpg", "profile.jpg"])) {
            if (file_exists($uploadDir . $fotoName)) {
                @unlink($uploadDir . $fotoName);
            }
        }
        $fotoName = $newFoto;
    }
}

// Proses Update Audio Baru
if (isset($_FILES["audio"]) && $_FILES["audio"]["error"] === UPLOAD_ERR_OK) {
    $audioExt = strtolower(pathinfo($_FILES["audio"]["name"], PATHINFO_EXTENSION));
    $allowedAudio = ["mp3", "wav", "ogg", "m4a"];

    if (in_array($audioExt, $allowedAudio) && $_FILES["audio"]["size"] <= 10 * 1024 * 1024) {
        $uploadAudioDir = __DIR__ . "/../uploads/audio/";
        if (!is_dir($uploadAudioDir)) {
            mkdir($uploadAudioDir, 0777, true);
        }
        $newAudio = "audio_" . time() . "_" . bin2hex(random_bytes(4)) . "." . $audioExt;
        if (move_uploaded_file($_FILES["audio"]["tmp_name"], $uploadAudioDir . $newAudio)) {
            if (!empty($audioName) && file_exists($uploadAudioDir . $audioName)) {
                @unlink($uploadAudioDir . $audioName);
            }
            $audioName = $newAudio;
        }
    }
}

$stmt = $conn->prepare(
    "UPDATE mahasiswa
    SET foto = ?, nim = ?, nama = ?, program_studi = ?, email = ?, audio = ?
    WHERE id = ?"
);

if (!$stmt) {
    die("Query error: " . $conn->error);
}

$stmt->bind_param("ssssssi", $fotoName, $nim, $nama, $program_studi, $email, $audioName, $id);

if ($stmt->execute()) {
    $stmt->close();
    $conn->close();
    header("Location: ../crud/index.php?status=update");
    exit;
} else {
    die("Gagal memperbarui data: " . $stmt->error . ". <a href='../crud/edit.php?id=" . $id . "'>Kembali ke Form Edit</a>");
}
?>
