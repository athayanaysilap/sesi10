<?php
require_once "../config/auth.php";
require_once "../config/koneksi.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../crud/tambah.php");
    exit;
}

$nim = trim($_POST["nim"] ?? "");
$nama = trim($_POST["nama"] ?? "");
$program_studi = trim($_POST["program_studi"] ?? "");
$email = trim($_POST["email"] ?? "");

if ($nim === "" || $nama === "" || $program_studi === "" || $email === "") {
    die("Semua field wajib diisi. <a href='../crud/tambah.php'>Kembali ke Form</a>");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Format email tidak valid. <a href='../crud/tambah.php'>Kembali ke Form</a>");
}

// Proses Upload Foto
$fotoName = "default-avatar.svg";
if (isset($_FILES["foto"]) && $_FILES["foto"]["error"] === UPLOAD_ERR_OK) {
    $allowedImg = ["image/jpeg" => "jpg", "image/png" => "png", "image/webp" => "webp", "image/gif" => "gif"];
    $fileTmp = $_FILES["foto"]["tmp_name"];
    $fileSize = $_FILES["foto"]["size"];
    $fileExt = strtolower(pathinfo($_FILES["foto"]["name"], PATHINFO_EXTENSION));

    if ($fileSize > 2 * 1024 * 1024) {
        die("Ukuran foto maksimal 2MB. <a href='../crud/tambah.php'>Kembali</a>");
    }

    if (!in_array($fileExt, ["jpg", "jpeg", "png", "webp", "gif"])) {
        die("Format foto tidak didukung (gunakan JPG, PNG, WEBP). <a href='../crud/tambah.php'>Kembali</a>");
    }

    $uploadDir = __DIR__ . "/../uploads/images/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $fotoName = "foto_" . time() . "_" . bin2hex(random_bytes(4)) . "." . $fileExt;
    if (!move_uploaded_file($fileTmp, $uploadDir . $fotoName)) {
        $fotoName = "default-avatar.svg";
    }
}

// Proses Upload Audio (Opsional)
$audioName = null;
if (isset($_FILES["audio"]) && $_FILES["audio"]["error"] === UPLOAD_ERR_OK) {
    $audioExt = strtolower(pathinfo($_FILES["audio"]["name"], PATHINFO_EXTENSION));
    $allowedAudio = ["mp3", "wav", "ogg", "m4a"];

    if (in_array($audioExt, $allowedAudio) && $_FILES["audio"]["size"] <= 10 * 1024 * 1024) {
        $uploadAudioDir = __DIR__ . "/../uploads/audio/";
        if (!is_dir($uploadAudioDir)) {
            mkdir($uploadAudioDir, 0777, true);
        }
        $audioName = "audio_" . time() . "_" . bin2hex(random_bytes(4)) . "." . $audioExt;
        if (!move_uploaded_file($_FILES["audio"]["tmp_name"], $uploadAudioDir . $audioName)) {
            $audioName = null;
        }
    }
}

$stmt = $conn->prepare(
    "INSERT INTO mahasiswa (foto, nim, nama, program_studi, email, audio)
    VALUES (?, ?, ?, ?, ?, ?)"
);

if (!$stmt) {
    die("Query error: " . $conn->error);
}

$stmt->bind_param("ssssss", $fotoName, $nim, $nama, $program_studi, $email, $audioName);

if ($stmt->execute()) {
    $stmt->close();
    $conn->close();
    header("Location: ../crud/index.php?status=tambah");
    exit;
} else {
    die("Gagal menambah data: " . $stmt->error . ". <a href='../crud/tambah.php'>Kembali ke Form</a>");
}
?>
