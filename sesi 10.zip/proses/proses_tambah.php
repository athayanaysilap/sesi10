<?php
require_once "../config/auth.php";
require_once "../config/koneksi.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../pages/form_mahasiswa.php");
    exit;
}

$nim = trim($_POST["nim"] ?? "");
$nama = trim($_POST["nama"] ?? "");
$program_studi = trim($_POST["program_studi"] ?? "");
$email = trim($_POST["email"] ?? "");

if (
    $nim === "" ||
    $nama === "" ||
    $program_studi === "" ||
    $email === ""
) {
    die("Semua field wajib diisi. <a href='../pages/form_mahasiswa.php'>Kembali ke Form</a>");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Format email tidak valid. <a href='../pages/form_mahasiswa.php'>Kembali ke Form</a>");
}

// Upload foto jika ada
$fotoName = "default-avatar.svg";
if (isset($_FILES["foto"]) && $_FILES["foto"]["error"] === UPLOAD_ERR_OK) {
    $fileTmp = $_FILES["foto"]["tmp_name"];
    $fileSize = $_FILES["foto"]["size"];
    $fileExt = strtolower(pathinfo($_FILES["foto"]["name"], PATHINFO_EXTENSION));

    if ($fileSize <= 2 * 1024 * 1024 && in_array($fileExt, ["jpg", "jpeg", "png", "webp", "gif"])) {
        $uploadDir = __DIR__ . "/../uploads/images/";
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        $newFoto = "foto_" . time() . "_" . bin2hex(random_bytes(4)) . "." . $fileExt;
        if (move_uploaded_file($fileTmp, $uploadDir . $newFoto)) {
            $fotoName = $newFoto;
        }
    }
}

$stmt = $conn->prepare(
    "INSERT INTO mahasiswa
    (foto, nim, nama, program_studi, email)
    VALUES (?, ?, ?, ?, ?)"
);

if (!$stmt) {
    die("Query error: " . $conn->error);
}

$stmt->bind_param(
    "sssss",
    $fotoName,
    $nim,
    $nama,
    $program_studi,
    $email
);

if ($stmt->execute()) {
    $stmt->close();
    $conn->close();
    header("Location: ../pages/data_mahasiswa.php?status=sukses");
    exit;
} else {
    die("Gagal menyimpan data: " . $stmt->error . ". <a href='../pages/form_mahasiswa.php'>Kembali ke Form</a>");
}
?>
