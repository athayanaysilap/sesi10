<?php
require_once "../config/auth.php";
require_once "../config/koneksi.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../crud/index.php");
    exit;
}

$id = (int) ($_POST["id"] ?? 0);
if ($id <= 0) {
    die("ID tidak valid. <a href='../crud/index.php'>Kembali ke CRUD</a>");
}

// Ambil info file foto dan audio sebelum data dihapus
$qOld = $conn->prepare("SELECT foto, audio FROM mahasiswa WHERE id = ? LIMIT 1");
if ($qOld) {
    $qOld->bind_param("i", $id);
    $qOld->execute();
    $row = $qOld->get_result()->fetch_assoc();
    $qOld->close();

    if ($row) {
        $foto = $row["foto"] ?? "";
        if (!empty($foto) && !in_array($foto, ["default-avatar.svg", "foto.jpg", "profile.jpg"])) {
            $fotoPath = __DIR__ . "/../uploads/images/" . $foto;
            if (file_exists($fotoPath)) {
                @unlink($fotoPath);
            }
        }

        $audio = $row["audio"] ?? "";
        if (!empty($audio)) {
            $audioPath = __DIR__ . "/../uploads/audio/" . $audio;
            if (file_exists($audioPath)) {
                @unlink($audioPath);
            }
        }
    }
}

$stmt = $conn->prepare("DELETE FROM mahasiswa WHERE id = ?");
if (!$stmt) {
    die("Query error: " . $conn->error);
}

$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    $stmt->close();
    $conn->close();
    header("Location: ../crud/index.php?status=hapus");
    exit;
} else {
    die("Gagal menghapus data: " . $stmt->error . ". <a href='../crud/index.php'>Kembali ke CRUD</a>");
}
?>
