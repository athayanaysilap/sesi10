<?php
require_once "../config/koneksi.php";

$username = "admin";
$password = "admin123";
$nama_lengkap = "Administrator";

$cek = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
if (!$cek) {
    die("Tabel users belum ada atau query error: " . $conn->error . ". Pastikan database <code>web_programming_1</code> dan tabel sudah diimpor dari <code>database/database.sql</code>.");
}

$cek->bind_param("s", $username);
$cek->execute();
$hasil_cek = $cek->get_result();

if ($hasil_cek && $hasil_cek->num_rows > 0) {
    $cek->close();
    $conn->close();
    die("User admin sudah ada. Silakan lanjut ke halaman login: <a href='../pages/login.php'>Login</a> (Username: admin, Password: admin123)");
}
$cek->close();

$password_hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $conn->prepare(
    "INSERT INTO users (username, password_hash, nama_lengkap) VALUES (?, ?, ?)"
);
if (!$stmt) {
    die("Gagal menyiapkan query insert: " . $conn->error);
}

$stmt->bind_param("sss", $username, $password_hash, $nama_lengkap);

if ($stmt->execute()) {
    echo "User berhasil dibuat. Silakan login: <a href='../pages/login.php'>Login</a> (Username: admin, Password: admin123)";
} else {
    echo "Gagal membuat user: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
