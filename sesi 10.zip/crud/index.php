<?php
require_once "../config/auth.php";
require_once "../config/koneksi.php";

$sql = "SELECT id, foto, nim, nama, program_studi, email, audio
        FROM mahasiswa
        ORDER BY id DESC";
$result = $conn->query($sql);
if (!$result) {
    die("Query error: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Mahasiswa</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<header>
    <h1>CRUD Mahasiswa</h1>
    <p>Web Programming 1</p>
</header>

<nav>
    <a href="../pages/dashboard.php">Dashboard</a>
    <a href="../pages/index.php">Biodata</a>
    <a href="../pages/layout.php">Layout Lab</a>
    <a href="../pages/data_mahasiswa.php">Data Mahasiswa</a>
    <a href="../pages/form_mahasiswa.php">Tambah Mahasiswa</a>
    <a href="index.php" class="active">CRUD Mahasiswa</a>
    <a href="../proses/logout.php">Logout</a>
</nav>

<main>
<section>
    <?php if (isset($_GET["status"])): ?>
        <?php if ($_GET["status"] === "tambah"): ?>
            <p class="alert-sukses">Data mahasiswa berhasil ditambahkan.</p>
        <?php elseif ($_GET["status"] === "update"): ?>
            <p class="alert-sukses">Data mahasiswa berhasil diperbarui.</p>
        <?php elseif ($_GET["status"] === "hapus"): ?>
            <p class="alert-sukses">Data mahasiswa berhasil dihapus.</p>
        <?php endif; ?>
    <?php endif; ?>

    <div class="crud-toolbar">
        <a class="btn" href="tambah.php">+ Tambah Data</a>
        <input type="search" id="searchMahasiswa" placeholder="Cari NIM, nama, prodi, email...">
    </div>

    <table class="data-table" id="crudTable">
        <thead>
            <tr>
                <th style="width: 50px;">No</th>
                <th style="width: 70px; text-align: center;">Foto</th>
                <th>NIM</th>
                <th>Nama</th>
                <th>Program Studi</th>
                <th>Email</th>
                <th style="width: 140px; text-align: center;">Audio</th>
                <th style="width: 140px;">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php if ($result->num_rows === 0): ?>
            <tr id="noDataRow">
                <td colspan="8" style="text-align: center; color: #666; padding: 20px;">
                    Belum ada data mahasiswa. Silakan klik tombol <strong>+ Tambah Data</strong>.
                </td>
            </tr>
        <?php else: ?>
            <?php $no = 1; ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <?php
                    $fotoFile = $row["foto"] ?? "";
                    $fotoSrc = "../assets/images/default-avatar.svg";
                    if (!empty($fotoFile)) {
                        if (file_exists(__DIR__ . "/../uploads/images/" . $fotoFile)) {
                            $fotoSrc = "../uploads/images/" . htmlspecialchars($fotoFile);
                        } elseif (file_exists(__DIR__ . "/../assets/images/" . $fotoFile)) {
                            $fotoSrc = "../assets/images/" . htmlspecialchars($fotoFile);
                        }
                    }
                ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td style="text-align: center;">
                        <img src="<?= $fotoSrc ?>" alt="Foto <?= htmlspecialchars($row["nama"]) ?>" class="table-photo">
                    </td>
                    <td><?= htmlspecialchars($row["nim"]); ?></td>
                    <td><?= htmlspecialchars($row["nama"]); ?></td>
                    <td><?= htmlspecialchars($row["program_studi"]); ?></td>
                    <td><?= htmlspecialchars($row["email"]); ?></td>
                    <td style="text-align: center;">
                        <?php if (!empty($row["audio"]) && file_exists(__DIR__ . "/../uploads/audio/" . $row["audio"])): ?>
                            <audio class="table-audio" controls src="../uploads/audio/<?= htmlspecialchars($row["audio"]) ?>"></audio>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td class="actions">
                        <a href="edit.php?id=<?= $row["id"]; ?>">Edit</a>

                        <form action="../proses/proses_hapus.php"
                              method="POST"
                              class="delete-form">
                            <input type="hidden" name="id" value="<?= $row["id"]; ?>">
                            <button type="submit" class="btn-delete">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php endif; ?>
        </tbody>
    </table>
</section>
</main>

<footer>
    <p>Web Programming 1</p>
</footer>

<script src="../assets/js/crud.js"></script>
</body>
</html>
<?php
$conn->close();
?>
