<?php
require_once "../config/auth.php";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data CRUD</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<header>
    <h1>Tambah Data CRUD</h1>
    <p>Form baru khusus area CRUD</p>
</header>

<nav>
    <a href="../pages/dashboard.php">Dashboard</a>
    <a href="../pages/index.php">Biodata</a>
    <a href="../pages/layout.php">Layout Lab</a>
    <a href="../pages/data_mahasiswa.php">Data Mahasiswa</a>
    <a href="../pages/form_mahasiswa.php">Tambah Mahasiswa</a>
    <a href="index.php" class="active">CRUD Mahasiswa</a>
    <a href="../proses/logout.php">Logout</a>
</nav>

<main>
<section>
<form class="crud-form"
      data-crud-form
      action="../proses/proses_crud_tambah.php"
      method="POST"
      enctype="multipart/form-data"
      novalidate>

    <label for="foto">Foto Mahasiswa</label>
    <input id="foto" name="foto" type="file" accept="image/jpeg,image/png,image/webp">
    <div class="photo-preview-container" id="previewContainer" style="display: none; margin-top: 8px;">
        <img id="previewImage" src="" alt="Preview Foto" class="table-photo" style="width: 70px; height: 70px;">
    </div>
    <small class="form-error" id="errorFoto"></small>

    <label for="nim">NIM</label>
    <input id="nim" name="nim" type="text" required>
    <small class="form-error" id="errorNim"></small>

    <label for="nama">Nama</label>
    <input id="nama" name="nama" type="text" required>
    <small class="form-error" id="errorNama"></small>

    <label for="program_studi">Program Studi</label>
    <input id="program_studi" name="program_studi" type="text" required>
    <small class="form-error" id="errorProdi"></small>

    <label for="email">Email</label>
    <input id="email" name="email" type="email" required>
    <small class="form-error" id="errorEmail"></small>

    <label for="audio">Audio Mahasiswa (Opsional)</label>
    <input id="audio" name="audio" type="file" accept="audio/*">
    <small class="form-error" id="errorAudio"></small>

    <button type="submit">Simpan Data</button>
    <a href="index.php">Batal</a>
</form>
</section>
</main>

<footer>
    <p>Web Programming 1</p>
</footer>

<script src="../assets/js/crud.js"></script>
</body>
</html>
