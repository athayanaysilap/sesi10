<?php
require_once "../config/auth.php";
require_once "../config/koneksi.php";

$id = (int) ($_GET["id"] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

$stmt = $conn->prepare("SELECT id, foto, nim, nama, program_studi, email, audio FROM mahasiswa WHERE id = ? LIMIT 1");
if (!$stmt) {
    die("Query error: " . $conn->error);
}
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$mahasiswa = $result->fetch_assoc();

if (!$mahasiswa) {
    $stmt->close();
    $conn->close();
    die("Data mahasiswa tidak ditemukan. <a href='index.php'>Kembali ke CRUD</a>");
}
$stmt->close();
$conn->close();

$currentFoto = $mahasiswa["foto"] ?? "";
$fotoSrc = "../assets/images/default-avatar.svg";
if (!empty($currentFoto)) {
    if (file_exists(__DIR__ . "/../uploads/images/" . $currentFoto)) {
        $fotoSrc = "../uploads/images/" . htmlspecialchars($currentFoto);
    } elseif (file_exists(__DIR__ . "/../assets/images/" . $currentFoto)) {
        $fotoSrc = "../assets/images/" . htmlspecialchars($currentFoto);
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data CRUD</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<header>
    <h1>Edit Data CRUD</h1>
    <p>Form edit khusus area CRUD</p>
</header>

<nav>
    <a href="../pages/dashboard.php">Dashboard</a>
    <a href="../pages/index.php">Biodata</a>
    <a href="../pages/layout.php">Layout Lab</a>
    <a href="../pages/data_mahasiswa.php">Data Mahasiswa</a>
    <a href="../pages/form_mahasiswa.php">Tambah Mahasiswa</a>
    <a href="index.php" class="active">CRUD Mahasiswa</a>
    <a href="../proses/logout.php">Logout</a>
</nav>

<main>
<section>
<form class="crud-form"
      data-crud-form
      action="../proses/proses_update.php"
      method="POST"
      enctype="multipart/form-data"
      novalidate>

    <input type="hidden" name="id" value="<?= htmlspecialchars($mahasiswa['id']) ?>">

    <div style="margin-bottom: 14px;">
        <label>Foto Saat Ini:</label>
        <div style="display: flex; align-items: center; gap: 12px; margin-top: 6px;">
            <img id="currentPhoto" src="<?= $fotoSrc ?>" alt="Foto <?= htmlspecialchars($mahasiswa['nama']) ?>" class="table-photo" style="width: 70px; height: 70px; margin: 0;">
            <span style="font-size: 0.85em; color: #666;"><?= htmlspecialchars($currentFoto ?: "default-avatar.svg") ?></span>
        </div>
    </div>

    <label for="foto">Ganti Foto (Kosongkan jika tidak diubah)</label>
    <input id="foto" name="foto" type="file" accept="image/jpeg,image/png,image/webp">
    <div class="photo-preview-container" id="previewContainer" style="display: none; margin-top: 8px;">
        <span style="font-size: 0.85em; color: #1f4e79; font-weight: bold;">Preview Foto Baru:</span>
        <img id="previewImage" src="" alt="Preview Foto Baru" class="table-photo" style="width: 70px; height: 70px; margin-top: 4px;">
    </div>
    <small class="form-error" id="errorFoto"></small>

    <label for="nim">NIM</label>
    <input id="nim" name="nim" type="text" value="<?= htmlspecialchars($mahasiswa['nim']) ?>" required>
    <small class="form-error" id="errorNim"></small>

    <label for="nama">Nama</label>
    <input id="nama" name="nama" type="text" value="<?= htmlspecialchars($mahasiswa['nama']) ?>" required>
    <small class="form-error" id="errorNama"></small>

    <label for="program_studi">Program Studi</label>
    <input id="program_studi" name="program_studi" type="text" value="<?= htmlspecialchars($mahasiswa['program_studi']) ?>" required>
    <small class="form-error" id="errorProdi"></small>

    <label for="email">Email</label>
    <input id="email" name="email" type="email" value="<?= htmlspecialchars($mahasiswa['email']) ?>" required>
    <small class="form-error" id="errorEmail"></small>

    <div style="margin-top: 10px; margin-bottom: 6px;">
        <label for="audio">File Audio (Opsional)</label>
        <?php if (!empty($mahasiswa["audio"]) && file_exists(__DIR__ . "/../uploads/audio/" . $mahasiswa["audio"])): ?>
            <div style="margin-top: 4px; margin-bottom: 6px;">
                <audio class="table-audio" controls src="../uploads/audio/<?= htmlspecialchars($mahasiswa["audio"]) ?>"></audio>
            </div>
        <?php endif; ?>
        <input id="audio" name="audio" type="file" accept="audio/*">
        <small class="form-error" id="errorAudio"></small>
    </div>

    <button type="submit">Update Data</button>
    <a href="index.php">Batal</a>
</form>
</section>
</main>

<footer>
    <p>Web Programming 1</p>
</footer>

<script src="../assets/js/crud.js"></script>
</body>
</html>
