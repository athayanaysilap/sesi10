document.addEventListener("DOMContentLoaded", function () {
    // Step 8 - Validasi client-side untuk data-crud-form
    const form = document.querySelector("[data-crud-form]");

    if (form) {
        const nim = document.getElementById("nim");
        const nama = document.getElementById("nama");
        const prodi = document.getElementById("program_studi");
        const email = document.getElementById("email");

        // Hapus tanda error saat user mengetik
        [nim, nama, prodi, email].forEach(function (input) {
            if (input) {
                input.addEventListener("input", function () {
                    this.classList.remove("is-invalid");
                    let errorElId = "error" + this.id.charAt(0).toUpperCase() + this.id.slice(1);
                    if (this.id === "program_studi") {
                        errorElId = "errorProdi";
                    }
                    const errEl = document.getElementById(errorElId);
                    if (errEl) {
                        errEl.textContent = "";
                    }
                });
            }
        });

        form.addEventListener("submit", function (event) {
            let valid = true;

            document.querySelectorAll(".form-error").forEach(function (el) {
                el.textContent = "";
            });

            document.querySelectorAll(".is-invalid").forEach(function (el) {
                el.classList.remove("is-invalid");
            });

            if (nim && nim.value.trim() === "") {
                const err = document.getElementById("errorNim");
                if (err) err.textContent = "NIM wajib diisi.";
                nim.classList.add("is-invalid");
                valid = false;
            }

            if (nama && nama.value.trim() === "") {
                const err = document.getElementById("errorNama");
                if (err) err.textContent = "Nama wajib diisi.";
                nama.classList.add("is-invalid");
                valid = false;
            }

            if (prodi && prodi.value.trim() === "") {
                const err = document.getElementById("errorProdi");
                if (err) err.textContent = "Program studi wajib diisi.";
                prodi.classList.add("is-invalid");
                valid = false;
            }

            if (email && (email.value.trim() === "" || !email.checkValidity())) {
                const err = document.getElementById("errorEmail");
                if (err) err.textContent = "Email wajib menggunakan format yang valid.";
                email.classList.add("is-invalid");
                valid = false;
            }

            if (!valid) {
                event.preventDefault();
                alert("Form belum valid. Periksa kembali data Anda.");
            }
        });
    }

    // Preview gambar saat memilih file foto
    const fotoInput = document.getElementById("foto");
    const previewContainer = document.getElementById("previewContainer");
    const previewImage = document.getElementById("previewImage");

    if (fotoInput && previewImage && previewContainer) {
        fotoInput.addEventListener("change", function () {
            const file = this.files && this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    previewImage.src = e.target.result;
                    previewContainer.style.display = "block";
                };
                reader.readAsDataURL(file);
            } else {
                previewContainer.style.display = "none";
            }
        });
    }

    // Step 13 - Tambahkan confirm delete ke crud.js
    const deleteForms = document.querySelectorAll(".delete-form");

    deleteForms.forEach(function (form) {
        form.addEventListener("submit", function (event) {
            const yakin = confirm("Yakin ingin menghapus data ini?");

            if (!yakin) {
                event.preventDefault();
            }
        });
    });

    // Step 14 - Tambahkan search ke crud.js (filter kolom NIM, Nama, Prodi, Email)
    const searchInput = document.getElementById("searchMahasiswa");
    const tableRows = document.querySelectorAll("#crudTable tbody tr");

    if (searchInput) {
        searchInput.addEventListener("input", function () {
            const keyword = searchInput.value.toLowerCase().trim();

            tableRows.forEach(function (row) {
                if (row.id === "noDataRow") return;

                const cells = row.querySelectorAll("td:not(.actions)");
                if (cells.length === 0) return;

                const text = Array.from(cells).map(function (c) {
                    return c.textContent;
                }).join(" ").toLowerCase();

                row.style.display = text.includes(keyword) ? "" : "none";
            });
        });
    }

    // Step 15 - Tambahkan feedback alert ke crud.js & bersihkan URL parameter
    const params = new URLSearchParams(window.location.search);
    const status = params.get("status");

    if (status === "tambah") {
        alert("Data berhasil ditambahkan.");
        window.history.replaceState({}, document.title, window.location.pathname);
    } else if (status === "update") {
        alert("Data berhasil diperbarui.");
        window.history.replaceState({}, document.title, window.location.pathname);
    } else if (status === "hapus") {
        alert("Data berhasil dihapus.");
        window.history.replaceState({}, document.title, window.location.pathname);
    }
});
